#include "Ref.h"

CRef::CRef() :
	ref_(1)
{
}

CRef::~CRef()
{
}
