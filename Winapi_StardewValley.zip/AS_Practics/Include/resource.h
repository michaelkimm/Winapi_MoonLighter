//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// AS_Practics.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDI_ICON1                       101
#define IDR_MENU1                       102
#define IDD_DIALOG1                     103
#define IDR_MENU2                       105
#define IDR_MAP_TOOL_MENU               106
#define IDR_MAP_TOOL_TOOLBAR            107
#define IDD_DIALOG_TSS                  109
#define IDD_DIALOG_LAYER                111
#define IDD_DIALOG_TILESET_SETTING      113
#define IDC_TAB1                        1001
#define IDC_TSS_COMBO                   1002
#define ID_TSS_OK                       1003
#define IDR_LAYER_FLOOR                 1004
#define IDR_LAYER_OBJECT                1005
#define IDBTN_LAYER_OK                  1007
#define IDC_SCROLLBAR1                  1008
#define ID_FILENEW                      40002
#define ID_NEWMAP                       40006
#define ID_STOREMAP                     40007
#define ID_SAVEMAP                      40008
#define ID_TILESET_SELECTION            40011
#define ID_TILESET_SETTING              40012
#define ID_HELP                         40014
#define ID_LOADMAP                      40015
#define ID_NEW_MAP                      40016
#define ID_SAVE_MAP                     40017
#define ID_LOAD_MAP                     40018
#define ID_BT_SAVE                      40022
#define ID_BT_NEW                       40023
#define ID_BT_LOAD                      40024
#define ID_40025                        40025
#define ID_LAYER_SELECTION              40026

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        115
#define _APS_NEXT_COMMAND_VALUE         40027
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
